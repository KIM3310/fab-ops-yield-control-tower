"""Semiconductor ops platform package."""
