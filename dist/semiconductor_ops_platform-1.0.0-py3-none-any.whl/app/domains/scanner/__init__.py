"""Scanner field response domain."""
